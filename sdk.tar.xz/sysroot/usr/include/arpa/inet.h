// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#include <stdint.h>
#include <sys/types.h>
#include <arpa/in.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef uint32_t in_addr_t;


const char *inet_ntop(int af, const void *src, char *dst, socklen_t size);
int inet_pton(int af, const char *src, void *dst);

in_addr_t inet_addr(const char *cp);
char *inet_ntoa(struct in_addr in);

uint16_t htons(uint16_t);
uint16_t ntohs(uint16_t);
uint32_t htonl(uint32_t);
uint32_t ntohl(uint32_t);

#ifdef __cplusplus
}
#endif