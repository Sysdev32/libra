// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned long nfds_t;

struct pollfd {
    int   fd;        /* File descriptor */
    short events;    /* Requested events */
    short revents;   /* Returned events */
};

/* Requested/returned events */
#define POLLIN      0x0001
#define POLLPRI     0x0002
#define POLLOUT     0x0004
#define POLLERR     0x0008
#define POLLHUP     0x0010
#define POLLNVAL    0x0020

/* X/Open extensions */
#define POLLRDNORM  POLLIN
#define POLLRDBAND  0x0080
#define POLLWRNORM  POLLOUT
#define POLLWRBAND  0x0100

/* Linux extensions (harmless to define) */
#define POLLMSG     0x0400
#define POLLREMOVE  0x1000
#define POLLRDHUP   0x2000

int poll(struct pollfd *fds, nfds_t nfds, int timeout);

#ifdef __cplusplus
}
#endif