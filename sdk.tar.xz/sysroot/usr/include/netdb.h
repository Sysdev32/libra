#ifndef _NETDB_H
#define _NETDB_H

struct hostent;
struct servent;
struct protoent;
struct netent;

#endif