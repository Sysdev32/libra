#ifndef _FEATURES_H
#define _FEATURES_H

/* Compiler detection */
#if defined(__GNUC__)
# define __GNUC_PREREQ(maj, min) \
    ((__GNUC__ > (maj)) || (__GNUC__ == (maj) && __GNUC_MINOR__ >= (min)))
#else
# define __GNUC_PREREQ(maj, min) 0
#endif

/* C language version */
#if __STDC_VERSION__ >= 201112L
# define __USE_ISOC11 1
#endif

#if __STDC_VERSION__ >= 199901L
# define __USE_ISOC99 1
#endif

/* POSIX */
#define __USE_POSIX         1
#define __USE_POSIX2        1
#define __USE_POSIX199309   1
#define __USE_POSIX199506   1

/* X/Open */
#define __USE_XOPEN         1
#define __USE_XOPEN2K       1
#define __USE_XOPEN2K8      1

/* GNU extensions */
#ifdef _GNU_SOURCE
# define __USE_GNU 1
#endif

/* BSD extensions */
#ifdef _BSD_SOURCE
# define __USE_BSD 1
#endif

/* Default source enables common extensions */
#ifndef _GNU_SOURCE
# define _DEFAULT_SOURCE 1
#endif

#endif /* _FEATURES_H */