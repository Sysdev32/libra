#ifndef TGL_H
#define TGL_H

/* prefix the OpenGL function names with "t" to avoid conflicts with * system
 * OpenGL definitions
 */
#define TGL_PREFIX 1

/*
 * The following constants come from Mesa 3D Graphics Library.
 */
#define COMPILETIME_TINYGL_COMPAT_TEST 0

#define GL_VERSION_1_1 1

#ifdef __cplusplus
extern "C" {
#endif

enum {
    /* Boolean values */
    GL_FALSE = 0,
    GL_TRUE = 1,

    /* Data types */
    GL_BYTE = 0x1400,
    GL_UNSIGNED_BYTE = 0x1401,
    GL_SHORT = 0x1402,
    GL_UNSIGNED_SHORT = 0x1403,
    GL_INT = 0x1404,
    GL_UNSIGNED_INT = 0x1405,
    GL_FLOAT = 0x1406,
    GL_DOUBLE = 0x140A,
    GL_2_BYTES = 0x1407,
    GL_3_BYTES = 0x1408,
    GL_4_BYTES = 0x1409,
    GL_UNSIGNED_SHORT_5_6_5 = 0x140A,
    GL_UNSIGNED_INT_8_8_8_8 = 0x140B,

    /* Primitives */
    GL_LINES = 0x0001,
    GL_POINTS = 0x0000,
    GL_LINE_STRIP = 0x0003,
    GL_LINE_LOOP = 0x0002,
    GL_TRIANGLES = 0x0004,
    GL_TRIANGLE_STRIP = 0x0005,
    GL_TRIANGLE_FAN = 0x0006,
    GL_QUADS = 0x0007,
    GL_QUAD_STRIP = 0x0008,
    GL_POLYGON = 0x0009,
    GL_EDGE_FLAG = 0x0B43,

    /* Necessary for glBufferData */
    GL_STATIC_DRAW = 0x88E4,
    /* Vertex Arrays */
    GL_VERTEX_ARRAY = 0x8074,
    GL_VERTEX_BUFFER = 0x8074,
    GL_NORMAL_ARRAY = 0x8075,
    GL_NORMAL_BUFFER = 0x8075,
    GL_COLOR_ARRAY = 0x8076,
    GL_COLOR_BUFFER = 0x8076,
    GL_INDEX_ARRAY = 0x8077,
    GL_TEXTURE_COORD_ARRAY = 0x8078,
    GL_TEXTURE_COORD_BUFFER = 0x8078,
    GL_EDGE_FLAG_ARRAY = 0x8079,
    GL_VERTEX_ARRAY_SIZE = 0x807A,
    GL_VERTEX_ARRAY_TYPE = 0x807B,
    GL_VERTEX_ARRAY_STRIDE = 0x807C,
    GL_VERTEX_ARRAY_COUNT = 0x807D,
    GL_NORMAL_ARRAY_TYPE = 0x807E,
    GL_NORMAL_ARRAY_STRIDE = 0x807F,
    GL_NORMAL_ARRAY_COUNT = 0x8080,
    GL_COLOR_ARRAY_SIZE = 0x8081,
    GL_COLOR_ARRAY_TYPE = 0x8082,
    GL_COLOR_ARRAY_STRIDE = 0x8083,
    GL_COLOR_ARRAY_COUNT = 0x8084,
    GL_INDEX_ARRAY_TYPE = 0x8085,
    GL_INDEX_ARRAY_STRIDE = 0x8086,
    GL_INDEX_ARRAY_COUNT = 0x8087,
    GL_TEXTURE_COORD_ARRAY_SIZE = 0x8088,
    GL_TEXTURE_COORD_ARRAY_TYPE = 0x8089,
    GL_TEXTURE_COORD_ARRAY_STRIDE = 0x808A,
    GL_TEXTURE_COORD_ARRAY_COUNT = 0x808B,
    GL_EDGE_FLAG_ARRAY_STRIDE = 0x808C,
    GL_EDGE_FLAG_ARRAY_COUNT = 0x808D,
    GL_VERTEX_ARRAY_POINTER = 0x808E,
    GL_NORMAL_ARRAY_POINTER = 0x808F,
    GL_COLOR_ARRAY_POINTER = 0x8090,
    GL_INDEX_ARRAY_POINTER = 0x8091,
    GL_TEXTURE_COORD_ARRAY_POINTER = 0x8092,
    GL_EDGE_FLAG_ARRAY_POINTER = 0x8093,
    GL_V2F = 0x2A20,
    GL_V3F = 0x2A21,
    GL_C4UB_V2F = 0x2A22,
    GL_C4UB_V3F = 0x2A23,
    GL_C3F_V3F = 0x2A24,
    GL_N3F_V3F = 0x2A25,
    GL_C4F_N3F_V3F = 0x2A26,
    GL_T2F_V3F = 0x2A27,
    GL_T4F_V4F = 0x2A28,
    GL_T2F_C4UB_V3F = 0x2A29,
    GL_T2F_C3F_V3F = 0x2A2A,
    GL_T2F_N3F_V3F = 0x2A2B,
    GL_T2F_C4F_N3F_V3F = 0x2A2C,
    GL_T4F_C4F_N3F_V4F = 0x2A2D,

    /* Matrix Mode */
    GL_MATRIX_MODE = 0x0BA0,
    GL_MODELVIEW = 0x1700,
    GL_PROJECTION = 0x1701,
    GL_TEXTURE = 0x1702,

    /* Points */
    GL_POINT_SMOOTH = 0x0B10,
    GL_POINT_SIZE = 0x0B11,
    GL_POINT_SIZE_GRANULARITY = 0x0B13,
    GL_POINT_SIZE_RANGE = 0x0B12,

    /* Lines */
    GL_LINE_SMOOTH = 0x0B20,
    GL_LINE_STIPPLE = 0x0B24,
    GL_LINE_STIPPLE_PATTERN = 0x0B25,
    GL_LINE_STIPPLE_REPEAT = 0x0B26,
    GL_LINE_WIDTH = 0x0B21,
    GL_LINE_WIDTH_GRANULARITY = 0x0B23,
    GL_LINE_WIDTH_RANGE = 0x0B22,

    /* Polygons */
    GL_POINT = 0x1B00,
    GL_LINE = 0x1B01,
    GL_FILL = 0x1B02,
    GL_CCW = 0x0901,
    GL_CW = 0x0900,
    GL_FRONT = 0x0404,
    GL_BACK = 0x0405,
    GL_CULL_FACE = 0x0B44,
    GL_CULL_FACE_MODE = 0x0B45,
    GL_POLYGON_SMOOTH = 0x0B41,
    GL_POLYGON_STIPPLE = 0x0B42,
    GL_FRONT_FACE = 0x0B46,
    GL_POLYGON_MODE = 0x0B40,
    GL_POLYGON_OFFSET_FACTOR = 0x3038,
    GL_POLYGON_OFFSET_UNITS = 0x2A00,
    GL_POLYGON_OFFSET_POINT = 0x2A01,
    GL_POLYGON_OFFSET_LINE = 0x2A02,
    GL_POLYGON_OFFSET_FILL = 0x8037,

    /* Display Lists */
    GL_COMPILE = 0x1300,
    GL_COMPILE_AND_EXECUTE = 0x1301,
    GL_LIST_BASE = 0x0B32,
    GL_LIST_INDEX = 0x0B33,
    GL_LIST_MODE = 0x0B30,

    /*TinyGL Extension queries, they all start with 0xf*/
    GL_POLYGON_MAX_VERTEX = 0xf001,
    GL_MAX_BUFFERS = 0xf002,
    GL_TEXTURE_HASH_TABLE_SIZE = 0xf003,
    GL_MAX_TEXTURE_LEVELS = 0xf004,
    GL_MAX_SPECULAR_BUFFERS = 0xf005,
    GL_MAX_DISPLAY_LISTS = 0xf006,
    GL_ERROR_CHECK_LEVEL = 0xf007,
    GL_IS_SPECULAR_ENABLED = 0xf008,

    /* Depth buffer */
    GL_NEVER = 0x0200,
    GL_LESS = 0x0201,
    GL_GEQUAL = 0x0206,
    GL_LEQUAL = 0x0203,
    GL_GREATER = 0x0204,
    GL_NOTEQUAL = 0x0205,
    GL_EQUAL = 0x0202,
    GL_ALWAYS = 0x0207,
    GL_DEPTH_TEST = 0x0B71,
    GL_DEPTH_BITS = 0x0D56,
    GL_DEPTH_CLEAR_VALUE = 0x0B73,
    GL_DEPTH_FUNC = 0x0B74,
    GL_DEPTH_RANGE = 0x0B70,
    GL_DEPTH_WRITEMASK = 0x0B72,
    GL_DEPTH_COMPONENT = 0x1902,

    /* Lighting */
    GL_LIGHTING = 0x0B50,
    GL_LIGHT0 = 0x4000,
    GL_LIGHT1 = 0x4001,
    GL_LIGHT2 = 0x4002,
    GL_LIGHT3 = 0x4003,
    GL_LIGHT4 = 0x4004,
    GL_LIGHT5 = 0x4005,
    GL_LIGHT6 = 0x4006,
    GL_LIGHT7 = 0x4007,
    GL_LIGHT8 = 0x4008,
    GL_LIGHT9 = 0x4009,
    GL_LIGHT10 = 0x400A,
    GL_LIGHT11 = 0x400B,
    GL_LIGHT12 = 0x400C,
    GL_LIGHT13 = 0x400D,
    GL_LIGHT14 = 0x400E,
    GL_LIGHT15 = 0x400F,
    GL_SPOT_EXPONENT = 0x1205,
    GL_SPOT_CUTOFF = 0x1206,
    GL_CONSTANT_ATTENUATION = 0x1207,
    GL_LINEAR_ATTENUATION = 0x1208,
    GL_QUADRATIC_ATTENUATION = 0x1209,
    GL_AMBIENT = 0x1200,
    GL_DIFFUSE = 0x1201,
    GL_SPECULAR = 0x1202,
    GL_SHININESS = 0x1601,
    GL_EMISSION = 0x1600,
    GL_POSITION = 0x1203,
    GL_SPOT_DIRECTION = 0x1204,
    GL_AMBIENT_AND_DIFFUSE = 0x1602,
    GL_COLOR_INDEXES = 0x1603,
    GL_LIGHT_MODEL_TWO_SIDE = 0x0B52,
    GL_LIGHT_MODEL_LOCAL_VIEWER = 0x0B51,
    GL_LIGHT_MODEL_AMBIENT = 0x0B53,
    GL_FRONT_AND_BACK = 0x0408,
    GL_SHADE_MODEL = 0x0B54,
    GL_FLAT = 0x1D00,
    GL_SMOOTH = 0x1D01,
    GL_COLOR_MATERIAL = 0x0B57,
    GL_COLOR_MATERIAL_FACE = 0x0B55,
    GL_COLOR_MATERIAL_PARAMETER = 0x0B56,
    GL_NORMALIZE = 0x0BA1,

    /* User clipping planes */
    GL_CLIP_PLANE0 = 0x3000,
    GL_CLIP_PLANE1 = 0x3001,
    GL_CLIP_PLANE2 = 0x3002,
    GL_CLIP_PLANE3 = 0x3003,
    GL_CLIP_PLANE4 = 0x3004,
    GL_CLIP_PLANE5 = 0x3005,

    /* Accumulation buffer */
    GL_ACCUM_RED_BITS = 0x0D58,
    GL_ACCUM_GREEN_BITS = 0x0D59,
    GL_ACCUM_BLUE_BITS = 0x0D5A,
    GL_ACCUM_ALPHA_BITS = 0x0D5B,
    GL_ACCUM_CLEAR_VALUE = 0x0B80,
    GL_ACCUM = 0x0100,
    GL_ADD = 0x0104,
    GL_LOAD = 0x0101,
    GL_MULT = 0x0103,
    GL_RETURN = 0x0102,

    /* Alpha testing */
    GL_ALPHA_TEST = 0x0BC0,
    GL_ALPHA_TEST_REF = 0x0BC2,
    GL_ALPHA_TEST_FUNC = 0x0BC1,

    /* Blending */
    GL_BLEND = 0x0BE2,
    GL_BLEND_SRC = 0x0BE1,
    GL_BLEND_DST = 0x0BE0,
    GL_ZERO = 0,
    GL_ONE = 1,
    GL_SRC_COLOR = 0x0300,
    GL_ONE_MINUS_SRC_COLOR = 0x0301,
    GL_DST_COLOR = 0x0306,
    GL_ONE_MINUS_DST_COLOR = 0x0307,
    GL_SRC_ALPHA = 0x0302,
    GL_ONE_MINUS_SRC_ALPHA = 0x0303,
    GL_DST_ALPHA = 0x0304,
    GL_ONE_MINUS_DST_ALPHA = 0x0305,
    GL_SRC_ALPHA_SATURATE = 0x0308,
    GL_CONSTANT_COLOR = 0x8001,
    GL_ONE_MINUS_CONSTANT_COLOR = 0x8002,
    GL_CONSTANT_ALPHA = 0x8003,
    GL_ONE_MINUS_CONSTANT_ALPHA = 0x8004,

    /* Render Mode */
    GL_FEEDBACK = 0x1C01,
    GL_RENDER = 0x1C00,
    GL_SELECT = 0x1C02,

    /* Feedback */
    GL_2D = 0x0600,
    GL_3D = 0x0601,
    GL_3D_COLOR = 0x0602,
    GL_3D_COLOR_TEXTURE = 0x0603,
    GL_4D_COLOR_TEXTURE = 0x0604,
    GL_POINT_TOKEN = 0x0701,
    GL_LINE_TOKEN = 0x0702,
    GL_LINE_RESET_TOKEN = 0x0707,
    GL_POLYGON_TOKEN = 0x0703,
    GL_BITMAP_TOKEN = 0x0704,
    GL_DRAW_PIXEL_TOKEN = 0x0705,
    GL_COPY_PIXEL_TOKEN = 0x0706,
    GL_PASS_THROUGH_TOKEN = 0x0700,

    /* Fog */
    GL_FOG = 0x0B60,
    GL_FOG_MODE = 0x0B65,
    GL_FOG_DENSITY = 0x0B62,
    GL_FOG_COLOR = 0x0B66,
    GL_FOG_INDEX = 0x0B61,
    GL_FOG_START = 0x0B63,
    GL_FOG_END = 0x0B64,
    GL_LINEAR = 0x2601,
    GL_EXP = 0x0800,
    GL_EXP2 = 0x0801,

    /* Logic Ops */
    GL_LOGIC_OP = 0x0BF1,
    GL_LOGIC_OP_MODE = 0x0BF0,
    GL_CLEAR = 0x1500,
    GL_SET = 0x150F,
    GL_COPY = 0x1503,
    GL_COPY_INVERTED = 0x150C,
    GL_NOOP = 0x1505,
    GL_INVERT = 0x150A,
    GL_AND = 0x1501,
    GL_NAND = 0x150E,
    GL_OR = 0x1507,
    GL_NOR = 0x1508,
    GL_XOR = 0x1506,
    GL_EQUIV = 0x1509,
    GL_AND_REVERSE = 0x1502,
    GL_AND_INVERTED = 0x1504,
    GL_OR_REVERSE = 0x150B,
    GL_OR_INVERTED = 0x150D,

    /* Stencil */
    GL_STENCIL_TEST = 0x0B90,
    GL_STENCIL_WRITEMASK = 0x0B98,
    GL_STENCIL_BITS = 0x0D57,
    GL_STENCIL_FUNC = 0x0B92,
    GL_STENCIL_VALUE_MASK = 0x0B93,
    GL_STENCIL_REF = 0x0B97,
    GL_STENCIL_FAIL = 0x0B94,
    GL_STENCIL_PASS_DEPTH_PASS = 0x0B96,
    GL_STENCIL_PASS_DEPTH_FAIL = 0x0B95,
    GL_STENCIL_CLEAR_VALUE = 0x0B91,
    GL_STENCIL_INDEX = 0x1901,
    GL_KEEP = 0x1E00,
    GL_REPLACE = 0x1E01,
    GL_INCR = 0x1E02,
    GL_DECR = 0x1E03,

    /* Buffers, Pixel Drawing/Reading */
    GL_NONE = 0,
    GL_LEFT = 0x0406,
    GL_RIGHT = 0x0407,
    /*GL_FRONT = 0x0404, */
    /*GL_BACK = 0x0405, */
    /*GL_FRONT_AND_BACK = 0x0408, */
    GL_FRONT_LEFT = 0x0400,
    GL_FRONT_RIGHT = 0x0401,
    GL_BACK_LEFT = 0x0402,
    GL_BACK_RIGHT = 0x0403,
    GL_AUX0 = 0x0409,
    GL_AUX1 = 0x040A,
    GL_AUX2 = 0x040B,
    GL_AUX3 = 0x040C,
    GL_COLOR_INDEX = 0x1900,
    GL_RED = 0x1903,
    GL_GREEN = 0x1904,
    GL_BLUE = 0x1905,
    GL_ALPHA = 0x1906,
    GL_LUMINANCE = 0x1909,
    GL_LUMINANCE_ALPHA = 0x190A,
    GL_ALPHA_BITS = 0x0D55,
    GL_RED_BITS = 0x0D52,
    GL_GREEN_BITS = 0x0D53,
    GL_BLUE_BITS = 0x0D54,
    GL_INDEX_BITS = 0x0D51,
    GL_SUBPIXEL_BITS = 0x0D50,
    GL_AUX_BUFFERS = 0x0C00,
    GL_READ_BUFFER = 0x0C02,
    GL_DRAW_BUFFER = 0x0C01,
    GL_DOUBLEBUFFER = 0x0C32,
    GL_STEREO = 0x0C33,
    GL_BITMAP = 0x1A00,
    GL_COLOR = 0x1800,
    GL_DEPTH = 0x1801,
    GL_STENCIL = 0x1802,
    GL_DITHER = 0x0BD0,
    GL_RGB = 0x1907,
    GL_RGBA = 0x1908,

    /* Implementation limits */
    GL_MAX_LIST_NESTING = 0x0B31,
    GL_MAX_ATTRIB_STACK_DEPTH = 0x0D35,
    GL_MAX_MODELVIEW_STACK_DEPTH = 0x0D36,
    GL_MAX_NAME_STACK_DEPTH = 0x0D37,
    GL_MAX_PROJECTION_STACK_DEPTH = 0x0D38,
    GL_MAX_TEXTURE_STACK_DEPTH = 0x0D39,
    GL_MAX_EVAL_ORDER = 0x0D30,
    GL_MAX_LIGHTS = 0x0D31,
    GL_MAX_CLIP_PLANES = 0x0D32,
    GL_MAX_TEXTURE_SIZE = 0x0D33,
    GL_MAX_PIXEL_MAP_TABLE = 0x0D34,
    GL_MAX_VIEWPORT_DIMS = 0x0D3A,
    GL_MAX_CLIENT_ATTRIB_STACK_DEPTH = 0x0D3B,

    /* Gets */
    GL_ATTRIB_STACK_DEPTH = 0x0BB0,
    GL_COLOR_CLEAR_VALUE = 0x0C22,
    GL_COLOR_WRITEMASK = 0x0C23,
    GL_CURRENT_INDEX = 0x0B01,
    GL_CURRENT_COLOR = 0x0B00,
    GL_CURRENT_NORMAL = 0x0B02,
    GL_CURRENT_RASTER_COLOR = 0x0B04,
    GL_CURRENT_RASTER_DISTANCE = 0x0B09,
    GL_CURRENT_RASTER_INDEX = 0x0B05,
    GL_CURRENT_RASTER_POSITION = 0x0B07,
    GL_CURRENT_RASTER_TEXTURE_COORDS = 0x0B06,
    GL_CURRENT_RASTER_POSITION_VALID = 0x0B08,
    GL_CURRENT_TEXTURE_COORDS = 0x0B03,
    GL_INDEX_CLEAR_VALUE = 0x0C20,
    GL_INDEX_MODE = 0x0C30,
    GL_INDEX_WRITEMASK = 0x0C21,
    GL_MODELVIEW_MATRIX = 0x0BA6,
    GL_MODELVIEW_STACK_DEPTH = 0x0BA3,
    GL_NAME_STACK_DEPTH = 0x0D70,
    GL_PROJECTION_MATRIX = 0x0BA7,
    GL_PROJECTION_STACK_DEPTH = 0x0BA4,
    GL_RENDER_MODE = 0x0C40,
    GL_RGBA_MODE = 0x0C31,
    GL_TEXTURE_MATRIX = 0x0BA8,
    GL_TEXTURE_STACK_DEPTH = 0x0BA5,
    GL_VIEWPORT = 0x0BA2,

    /* Evaluators */
    GL_AUTO_NORMAL = 0x0D80,
    GL_MAP1_COLOR_4 = 0x0D90,
    GL_MAP1_GRID_DOMAIN = 0x0DD0,
    GL_MAP1_GRID_SEGMENTS = 0x0DD1,
    GL_MAP1_INDEX = 0x0D91,
    GL_MAP1_NORMAL = 0x0D92,
    GL_MAP1_TEXTURE_COORD_1 = 0x0D93,
    GL_MAP1_TEXTURE_COORD_2 = 0x0D94,
    GL_MAP1_TEXTURE_COORD_3 = 0x0D95,
    GL_MAP1_TEXTURE_COORD_4 = 0x0D96,
    GL_MAP1_VERTEX_3 = 0x0D97,
    GL_MAP1_VERTEX_4 = 0x0D98,
    GL_MAP2_COLOR_4 = 0x0DB0,
    GL_MAP2_GRID_DOMAIN = 0x0DD2,
    GL_MAP2_GRID_SEGMENTS = 0x0DD3,
    GL_MAP2_INDEX = 0x0DB1,
    GL_MAP2_NORMAL = 0x0DB2,
    GL_MAP2_TEXTURE_COORD_1 = 0x0DB3,
    GL_MAP2_TEXTURE_COORD_2 = 0x0DB4,
    GL_MAP2_TEXTURE_COORD_3 = 0x0DB5,
    GL_MAP2_TEXTURE_COORD_4 = 0x0DB6,
    GL_MAP2_VERTEX_3 = 0x0DB7,
    GL_MAP2_VERTEX_4 = 0x0DB8,
    GL_COEFF = 0x0A00,
    GL_DOMAIN = 0x0A02,
    GL_ORDER = 0x0A01,

    /* Hints */
    GL_FOG_HINT = 0x0C54,
    GL_LINE_SMOOTH_HINT = 0x0C52,
    GL_PERSPECTIVE_CORRECTION_HINT = 0x0C50,
    GL_POINT_SMOOTH_HINT = 0x0C51,
    GL_POLYGON_SMOOTH_HINT = 0x0C53,
    GL_DONT_CARE = 0x1100,
    GL_FASTEST = 0x1101,
    GL_NICEST = 0x1102,

    /* Scissor box */
    GL_SCISSOR_TEST = 0x0C11,
    GL_SCISSOR_BOX = 0x0C10,

    /* Pixel Mode / Transfer */
    GL_MAP_COLOR = 0x0D10,
    GL_MAP_STENCIL = 0x0D11,
    GL_INDEX_SHIFT = 0x0D12,
    GL_INDEX_OFFSET = 0x0D13,
    GL_RED_SCALE = 0x0D14,
    GL_RED_BIAS = 0x0D15,
    GL_GREEN_SCALE = 0x0D18,
    GL_GREEN_BIAS = 0x0D19,
    GL_BLUE_SCALE = 0x0D1A,
    GL_BLUE_BIAS = 0x0D1B,
    GL_ALPHA_SCALE = 0x0D1C,
    GL_ALPHA_BIAS = 0x0D1D,
    GL_DEPTH_SCALE = 0x0D1E,
    GL_DEPTH_BIAS = 0x0D1F,
    GL_PIXEL_MAP_S_TO_S_SIZE = 0x0CB1,
    GL_PIXEL_MAP_I_TO_I_SIZE = 0x0CB0,
    GL_PIXEL_MAP_I_TO_R_SIZE = 0x0CB2,
    GL_PIXEL_MAP_I_TO_G_SIZE = 0x0CB3,
    GL_PIXEL_MAP_I_TO_B_SIZE = 0x0CB4,
    GL_PIXEL_MAP_I_TO_A_SIZE = 0x0CB5,
    GL_PIXEL_MAP_R_TO_R_SIZE = 0x0CB6,
    GL_PIXEL_MAP_G_TO_G_SIZE = 0x0CB7,
    GL_PIXEL_MAP_B_TO_B_SIZE = 0x0CB8,
    GL_PIXEL_MAP_A_TO_A_SIZE = 0x0CB9,
    GL_PIXEL_MAP_S_TO_S = 0x0C71,
    GL_PIXEL_MAP_I_TO_I = 0x0C70,
    GL_PIXEL_MAP_I_TO_R = 0x0C72,
    GL_PIXEL_MAP_I_TO_G = 0x0C73,
    GL_PIXEL_MAP_I_TO_B = 0x0C74,
    GL_PIXEL_MAP_I_TO_A = 0x0C75,
    GL_PIXEL_MAP_R_TO_R = 0x0C76,
    GL_PIXEL_MAP_G_TO_G = 0x0C77,
    GL_PIXEL_MAP_B_TO_B = 0x0C78,
    GL_PIXEL_MAP_A_TO_A = 0x0C79,
    GL_PACK_ALIGNMENT = 0x0D05,
    GL_PACK_LSB_FIRST = 0x0D01,
    GL_PACK_ROW_LENGTH = 0x0D02,
    GL_PACK_SKIP_PIXELS = 0x0D04,
    GL_PACK_SKIP_ROWS = 0x0D03,
    GL_PACK_SWAP_BYTES = 0x0D00,
    GL_UNPACK_ALIGNMENT = 0x0CF5,
    GL_UNPACK_LSB_FIRST = 0x0CF1,
    GL_UNPACK_ROW_LENGTH = 0x0CF2,
    GL_UNPACK_SKIP_PIXELS = 0x0CF4,
    GL_UNPACK_SKIP_ROWS = 0x0CF3,
    GL_UNPACK_SWAP_BYTES = 0x0CF0,
    GL_ZOOM_X = 0x0D16,
    GL_ZOOM_Y = 0x0D17,

    /* Texture mapping */
    GL_TEXTURE_ENV = 0x2300,
    GL_TEXTURE_ENV_MODE = 0x2200,
    GL_TEXTURE_1D = 0x0DE0,
    GL_TEXTURE_2D = 0x0DE1,
    GL_TEXTURE_WRAP_S = 0x2802,
    GL_TEXTURE_WRAP_T = 0x2803,
    GL_TEXTURE_MAG_FILTER = 0x2800,
    GL_TEXTURE_MIN_FILTER = 0x2801,
    GL_TEXTURE_ENV_COLOR = 0x2201,
    GL_TEXTURE_GEN_S = 0x0C60,
    GL_TEXTURE_GEN_T = 0x0C61,
    GL_TEXTURE_GEN_MODE = 0x2500,
    GL_TEXTURE_BORDER_COLOR = 0x1004,
    GL_TEXTURE_WIDTH = 0x1000,
    GL_TEXTURE_HEIGHT = 0x1001,
    GL_TEXTURE_BORDER = 0x1005,
    GL_TEXTURE_COMPONENTS = 0x1003,
    GL_NEAREST_MIPMAP_NEAREST = 0x2700,
    GL_NEAREST_MIPMAP_LINEAR = 0x2702,
    GL_LINEAR_MIPMAP_NEAREST = 0x2701,
    GL_LINEAR_MIPMAP_LINEAR = 0x2703,
    GL_OBJECT_LINEAR = 0x2401,
    GL_OBJECT_PLANE = 0x2501,
    GL_EYE_LINEAR = 0x2400,
    GL_EYE_PLANE = 0x2502,
    GL_SPHERE_MAP = 0x2402,
    GL_DECAL = 0x2101,
    GL_MODULATE = 0x2100,
    GL_NEAREST = 0x2600,
    GL_REPEAT = 0x2901,
    GL_CLAMP = 0x2900,
    GL_S = 0x2000,
    GL_T = 0x2001,
    GL_R = 0x2002,
    GL_Q = 0x2003,
    GL_TEXTURE_GEN_R = 0x0C62,
    GL_TEXTURE_GEN_Q = 0x0C63,

    GL_PROXY_TEXTURE_1D = 0x8063,
    GL_PROXY_TEXTURE_2D = 0x8064,
    GL_TEXTURE_PRIORITY = 0x8066,
    GL_TEXTURE_RESIDENT = 0x8067,
    GL_TEXTURE_1D_BINDING = 0x8068,
    GL_TEXTURE_2D_BINDING = 0x8069,

    /* Internal texture formats */
    GL_ALPHA4 = 0x803B,
    GL_ALPHA8 = 0x803C,
    GL_ALPHA12 = 0x803D,
    GL_ALPHA16 = 0x803E,
    GL_LUMINANCE4 = 0x803F,
    GL_LUMINANCE8 = 0x8040,
    GL_LUMINANCE12 = 0x8041,
    GL_LUMINANCE16 = 0x8042,
    GL_LUMINANCE4_ALPHA4 = 0x8043,
    GL_LUMINANCE6_ALPHA2 = 0x8044,
    GL_LUMINANCE8_ALPHA8 = 0x8045,
    GL_LUMINANCE12_ALPHA4 = 0x8046,
    GL_LUMINANCE12_ALPHA12 = 0x8047,
    GL_LUMINANCE16_ALPHA16 = 0x8048,
    GL_INTENSITY = 0x8049,
    GL_INTENSITY4 = 0x804A,
    GL_INTENSITY8 = 0x804B,
    GL_INTENSITY12 = 0x804C,
    GL_INTENSITY16 = 0x804D,
    GL_R3_G3_B2 = 0x2A10,
    GL_RGB4 = 0x804F,
    GL_RGB5 = 0x8050,
    GL_RGB8 = 0x8051,
    GL_RGB10 = 0x8052,
    GL_RGB12 = 0x8053,
    GL_RGB16 = 0x8054,
    GL_RGBA2 = 0x8055,
    GL_RGBA4 = 0x8056,
    GL_RGB5_A1 = 0x8057,
    GL_RGBA8 = 0x8058,
    GL_RGB10_A2 = 0x8059,
    GL_RGBA12 = 0x805A,
    GL_RGBA16 = 0x805B,

    /* Utility */
    GL_VENDOR = 0x1F00,
    GL_RENDERER = 0x1F01,
    GL_VERSION = 0x1F02,
    GL_EXTENSIONS = 0x1F03,
    GL_LICENSE = 0x1F04,

    /* Errors */
    GL_NO_ERROR = 0x0,
    GL_INVALID_VALUE = 0x0501,
    GL_INVALID_ENUM = 0x0500,
    GL_INVALID_OPERATION = 0x0502,
    GL_STACK_OVERFLOW = 0x0503,
    GL_STACK_UNDERFLOW = 0x0504,
    GL_OUT_OF_MEMORY = 0x0505,

    /*
     * 1.0 Extensions
     */
    /* GL_EXT_blend_minmax and GL_EXT_blend_color */
    GL_CONSTANT_COLOR_EXT = 0x8001,
    GL_ONE_MINUS_CONSTANT_COLOR_EXT = 0x8002,
    GL_CONSTANT_ALPHA_EXT = 0x8003,
    GL_ONE_MINUS_CONSTANT_ALPHA_EXT = 0x8004,
    GL_BLEND_EQUATION_EXT = 0x8009,
    GL_BLEND_EQUATION = 0x8009,
    GL_MIN_EXT = 0x8007,
    GL_MAX_EXT = 0x8008,
    GL_FUNC_ADD_EXT = 0x8006,
    GL_FUNC_ADD = 0x8006,
    GL_FUNC_SUBTRACT_EXT = 0x800A,
    GL_FUNC_SUBTRACT = 0x800A,
    GL_FUNC_REVERSE_SUBTRACT_EXT = 0x800B,
    GL_FUNC_REVERSE_SUBTRACT = 0x800B,
    GL_BLEND_COLOR_EXT = 0x8005,

    /* GL_EXT_polygon_offset */
    GL_POLYGON_OFFSET_EXT = 0x8037,
    GL_POLYGON_OFFSET_FACTOR_EXT = 0x8038,
    GL_POLYGON_OFFSET_BIAS_EXT = 0x8039,
    /* GL */
    GL_ARRAY_BUFFER = 0x8892,
    /* GL_EXT_vertex_array */
    GL_VERTEX_ARRAY_EXT = 0x8074,
    GL_NORMAL_ARRAY_EXT = 0x8075,
    GL_COLOR_ARRAY_EXT = 0x8076,
    GL_INDEX_ARRAY_EXT = 0x8077,
    GL_TEXTURE_COORD_ARRAY_EXT = 0x8078,
    GL_EDGE_FLAG_ARRAY_EXT = 0x8079,
    GL_VERTEX_ARRAY_SIZE_EXT = 0x807A,
    GL_VERTEX_ARRAY_TYPE_EXT = 0x807B,
    GL_VERTEX_ARRAY_STRIDE_EXT = 0x807C,
    GL_VERTEX_ARRAY_COUNT_EXT = 0x807D,
    GL_NORMAL_ARRAY_TYPE_EXT = 0x807E,
    GL_NORMAL_ARRAY_STRIDE_EXT = 0x807F,
    GL_NORMAL_ARRAY_COUNT_EXT = 0x8080,
    GL_COLOR_ARRAY_SIZE_EXT = 0x8081,
    GL_COLOR_ARRAY_TYPE_EXT = 0x8082,
    GL_COLOR_ARRAY_STRIDE_EXT = 0x8083,
    GL_COLOR_ARRAY_COUNT_EXT = 0x8084,
    GL_INDEX_ARRAY_TYPE_EXT = 0x8085,
    GL_INDEX_ARRAY_STRIDE_EXT = 0x8086,
    GL_INDEX_ARRAY_COUNT_EXT = 0x8087,
    GL_TEXTURE_COORD_ARRAY_SIZE_EXT = 0x8088,
    GL_TEXTURE_COORD_ARRAY_TYPE_EXT = 0x8089,
    GL_TEXTURE_COORD_ARRAY_STRIDE_EXT = 0x808A,
    GL_TEXTURE_COORD_ARRAY_COUNT_EXT = 0x808B,
    GL_EDGE_FLAG_ARRAY_STRIDE_EXT = 0x808C,
    GL_EDGE_FLAG_ARRAY_COUNT_EXT = 0x808D,
    GL_VERTEX_ARRAY_POINTER_EXT = 0x808E,
    GL_NORMAL_ARRAY_POINTER_EXT = 0x808F,
    GL_COLOR_ARRAY_POINTER_EXT = 0x8090,
    GL_INDEX_ARRAY_POINTER_EXT = 0x8091,
    GL_TEXTURE_COORD_ARRAY_POINTER_EXT = 0x8092,
    GL_EDGE_FLAG_ARRAY_POINTER_EXT = 0x8093
};

typedef enum {
    GL_TEXT_SIZE8x8 = 1,
    GL_TEXT_SIZE16x16 = 2,
    GL_TEXT_SIZE24x24 = 3,
    GL_TEXT_SIZE32x32 = 4,
    GL_TEXT_SIZE40x40 = 5,
    GL_TEXT_SIZE48x48 = 6,
    GL_TEXT_SIZE56x56 = 7,
    GL_TEXT_SIZE64x64 = 8,
    GL_TEXT_SIZE72x72 = 9,
    GL_TEXT_SIZE80x80 = 10,
    GL_TEXT_SIZE88x88 = 11,
    GL_TEXT_SIZE96x96 = 12,
    GL_TEXT_SIZE104x104 = 13,
    GL_TEXT_SIZE112x112 = 14,
    GL_TEXT_SIZE120x120 = 15,
    GL_TEXT_SIZE128x128 = 16,
    GL_MAX_TEXT_SIZE = 16
} GLTEXTSIZE;

enum {
    GL_CURRENT_BIT = 0x00000001,
    GL_POINT_BIT = 0x00000002,
    GL_LINE_BIT = 0x00000004,
    GL_POLYGON_BIT = 0x00000008,
    GL_POLYGON_STIPPLE_BIT = 0x00000010,
    GL_PIXEL_MODE_BIT = 0x00000020,
    GL_LIGHTING_BIT = 0x00000040,
    GL_FOG_BIT = 0x00000080,
    GL_DEPTH_BUFFER_BIT = 0x00000100,
    GL_ACCUM_BUFFER_BIT = 0x00000200,
    GL_STENCIL_BUFFER_BIT = 0x00000400,
    GL_VIEWPORT_BIT = 0x00000800,
    GL_TRANSFORM_BIT = 0x00001000,
    GL_ENABLE_BIT = 0x00002000,
    GL_COLOR_BUFFER_BIT = 0x00004000,
    GL_HINT_BIT = 0x00008000,
    GL_EVAL_BIT = 0x00010000,
    GL_LIST_BIT = 0x00020000,
    GL_TEXTURE_BIT = 0x00040000,
    GL_SCISSOR_BIT = 0x00080000,
    GL_ALL_ATTRIB_BITS = 0x000fffff
};

/* some types */
typedef void GLvoid;
typedef unsigned char GLboolean;
typedef signed char GLbyte;      /* 1-byte signed */
typedef short GLshort;           /* 2-byte signed */
typedef int GLint;               /* 4-byte signed */
typedef GLint GLenum;            /* Same as GLint */
typedef unsigned char GLubyte;   /* 1-byte unsigned */
typedef unsigned short GLushort; /* 2-byte unsigned */
typedef unsigned int GLuint;     /* 4-byte unsigned */
typedef float GLfloat;           /* single precision float */
typedef double GLdouble;         /* double precision float */
typedef GLint GLsizei;           /* Same as GLint */

#if COMPILETIME_TINYGL_COMPAT_TEST == 1
/*
 * Test to ensure that these types are the correct size
 * If you get an "array is negative" error, simply change
 * the typedefs above to types which match the sizes tested for here.
 * Note that this library NEEDS a 4-byte float type (IEEE 754) so
 * if you don't have one, TinyGL is incompatible.
 */
extern char TGL_BUILDT_GLbyte[1 - 2 * (sizeof(GLbyte) != 1)];
#ifdef __STDC_IEC_559__
#if __STDC_IEC_559__ == 0
#error C99 Compiler Using Non-Compliant Float Type! Compatibility not guaranteed.
#endif
#else
#warning "Cannot test __STDC_IEC_559__, it is not defined."
#endif
extern char TGL_BUILDT_GLshort[1 - 2 * (sizeof(GLshort) != 2)];
extern char TGL_BUILDT_GLint[1 - 2 * (sizeof(GLint) != 4)];
extern char TGL_BUILDT_GLuint[1 - 2 * (sizeof(GLuint) != 4)];
extern char TGL_BUILDT_GLfloat[1 - 2 * (sizeof(GLfloat) != 4)];
extern char TGL_BUILDT_GLubyte[1 - 2 * (sizeof(GLubyte) != 1)];
extern char TGL_BUILDT_GLushort[1 - 2 * (sizeof(GLushort) != 2)];

extern char TGL_BUILDT_LshiftGLint[1 - 2 * (((GLint) 255 << 8) != 65280)];
extern char TGL_BUILDT_RshiftGLint[1 - 2 * ((GLint) 65280 >> 8 != 255)];
extern char TGL_BUILDT_RshiftGLint2[1 - 2 * (((GLint) -1) >> 14 != -1)];
extern char TGL_BUILDT_LshiftGLuint[1 - 2 * (((GLuint) 255 << 8) != 65280)];
extern char TGL_BUILDT_RshiftGLuint[1 - 2 * ((GLuint) 65280 >> 8 != 255)];

extern char TGL_BUILDT_LshiftGLushort[1 - 2 * (((GLushort) 255 << 8) != 65280)];
extern char TGL_BUILDT_RshiftGLushort[1 - 2 * ((GLushort) 65280 >> 8 != 255)];

extern char TGL_BUILDT_LshiftGLshort[1 - 2 * (((GLshort) 255 << 8) != 65280)];
extern char TGL_BUILDT_RshiftGLshort[1 - 2 * ((GLshort) 65280 >> 8 != -1)];

#undef T
#endif

#ifdef TGL_PREFIX
#define TGL_PREFIX_STR t
#define TGL_CONCAT2(a, b) a##b
#define TGL_CONCAT(a, b) TGL_CONCAT2(a, b)
#define TGL_ADD_PREFIX(b) TGL_CONCAT(TGL_PREFIX_STR, b)

#define glEnable TGL_ADD_PREFIX(glEnable)
#define glDisable TGL_ADD_PREFIX(glDisable)
#define glShadeModel TGL_ADD_PREFIX(glShadeModel)
#define glCullFace TGL_ADD_PREFIX(glCullFace)
#define glPolygonMode TGL_ADD_PREFIX(glPolygonMode)
#define glBegin TGL_ADD_PREFIX(glBegin)
#define glEnd TGL_ADD_PREFIX(glEnd)
#define glRectf TGL_ADD_PREFIX(glRectf)
#define glDrawBuffer TGL_ADD_PREFIX(glDrawBuffer)
#define glReadBuffer TGL_ADD_PREFIX(glReadBuffer)
#define glReadPixels TGL_ADD_PREFIX(glReadPixels)
#define glDrawArrays TGL_ADD_PREFIX(glDrawArrays)
#define glSetEnableSpecular TGL_ADD_PREFIX(glSetEnableSpecular)
#define glGetTexturePixmap TGL_ADD_PREFIX(glGetTexturePixmap)
#define glDrawText TGL_ADD_PREFIX(glDrawText)
#define glTextSize TGL_ADD_PREFIX(glTextSize)
#define glPlotPixel TGL_ADD_PREFIX(glPlotPixel)
#define glEdgeFlag TGL_ADD_PREFIX(glEdgeFlag)
#define glMatrixMode TGL_ADD_PREFIX(glMatrixMode)
#define glLoadMatrixf TGL_ADD_PREFIX(glLoadMatrixf)
#define glLoadIdentity TGL_ADD_PREFIX(glLoadIdentity)
#define glMultMatrixf TGL_ADD_PREFIX(glMultMatrixf)
#define glPushMatrix TGL_ADD_PREFIX(glPushMatrix)
#define glPopMatrix TGL_ADD_PREFIX(glPopMatrix)
#define glRotatef TGL_ADD_PREFIX(glRotatef)
#define glTranslatef TGL_ADD_PREFIX(glTranslatef)
#define glScalef TGL_ADD_PREFIX(glScalef)
#define glViewport TGL_ADD_PREFIX(glViewport)
#define glFrustum TGL_ADD_PREFIX(glFrustum)
#define glGenLists TGL_ADD_PREFIX(glGenLists)
#define glIsList TGL_ADD_PREFIX(glIsList)
#define glNewList TGL_ADD_PREFIX(glNewList)
#define glEndList TGL_ADD_PREFIX(glEndList)
#define glCallList TGL_ADD_PREFIX(glCallList)
#define glCallLists TGL_ADD_PREFIX(glCallLists)
#define glListBase TGL_ADD_PREFIX(glListBase)
#define glDeleteList TGL_ADD_PREFIX(glDeleteList)
#define glDeleteLists TGL_ADD_PREFIX(glDeleteLists)
#define glClear TGL_ADD_PREFIX(glClear)
#define glClearColor TGL_ADD_PREFIX(glClearColor)
#define glClearDepth TGL_ADD_PREFIX(glClearDepth)
#define glFeedbackBuffer TGL_ADD_PREFIX(glFeedbackBuffer)
#define glPassThrough TGL_ADD_PREFIX(glPassThrough)
#define glRenderMode TGL_ADD_PREFIX(glRenderMode)
#define glSelectBuffer TGL_ADD_PREFIX(glSelectBuffer)
#define glInitNames TGL_ADD_PREFIX(glInitNames)
#define glPushName TGL_ADD_PREFIX(glPushName)
#define glPopName TGL_ADD_PREFIX(glPopName)
#define glLoadName TGL_ADD_PREFIX(glLoadName)
#define glGenTextures TGL_ADD_PREFIX(glGenTextures)
#define glDeleteTextures TGL_ADD_PREFIX(glDeleteTextures)
#define glBindTexture TGL_ADD_PREFIX(glBindTexture)
#define glTexImage2D TGL_ADD_PREFIX(glTexImage2D)
#define glTexImage1D TGL_ADD_PREFIX(glTexImage1D)
#define glCopyTexImage2D TGL_ADD_PREFIX(glCopyTexImage2D)
#define glTexEnvi TGL_ADD_PREFIX(glTexEnvi)
#define glTexParameteri TGL_ADD_PREFIX(glTexParameteri)
#define glAreTexturesResident TGL_ADD_PREFIX(glAreTexturesResident)
#define glIsTexture TGL_ADD_PREFIX(glIsTexture)
#define glMaterialfv TGL_ADD_PREFIX(glMaterialfv)
#define glMaterialf TGL_ADD_PREFIX(glMaterialf)
#define glColorMaterial TGL_ADD_PREFIX(glColorMaterial)
#define glLightfv TGL_ADD_PREFIX(glLightfv)
#define glLightf TGL_ADD_PREFIX(glLightf)
#define glLightModeli TGL_ADD_PREFIX(glLightModeli)
#define glLightModelfv TGL_ADD_PREFIX(glLightModelfv)
#define glFlush TGL_ADD_PREFIX(glFlush)
#define glFinish TGL_ADD_PREFIX(glFinish)
#define glHint TGL_ADD_PREFIX(glHint)
#define glGetIntegerv TGL_ADD_PREFIX(glGetIntegerv)
#define glGetFloatv TGL_ADD_PREFIX(glGetFloatv)
#define glGetString TGL_ADD_PREFIX(glGetString)
#define glGetError TGL_ADD_PREFIX(glGetError)
#define glFrontFace TGL_ADD_PREFIX(glFrontFace)
#define glEnableClientState TGL_ADD_PREFIX(glEnableClientState)
#define glDisableClientState TGL_ADD_PREFIX(glDisableClientState)
#define glArrayElement TGL_ADD_PREFIX(glArrayElement)
#define glVertexPointer TGL_ADD_PREFIX(glVertexPointer)
#define glColorPointer TGL_ADD_PREFIX(glColorPointer)
#define glNormalPointer TGL_ADD_PREFIX(glNormalPointer)
#define glTexCoordPointer TGL_ADD_PREFIX(glTexCoordPointer)
#define glGenBuffers TGL_ADD_PREFIX(glGenBuffers)
#define glDeleteBuffers TGL_ADD_PREFIX(glDeleteBuffers)
#define glBindBuffer TGL_ADD_PREFIX(glBindBuffer)
#define glIsBuffer TGL_ADD_PREFIX(glIsBuffer)
#define glMapBuffer TGL_ADD_PREFIX(glMapBuffer)
#define glBufferData TGL_ADD_PREFIX(glBufferData)
#define glBindBufferAsArray TGL_ADD_PREFIX(glBindBufferAsArray)
#define glPolygonOffset TGL_ADD_PREFIX(glPolygonOffset)
#define glBlendFunc TGL_ADD_PREFIX(glBlendFunc)
#define glBlendEquation TGL_ADD_PREFIX(glBlendEquation)
#define glDepthMask TGL_ADD_PREFIX(glDepthMask)
#define glPointSize TGL_ADD_PREFIX(glPointSize)
#define glRasterPos2f TGL_ADD_PREFIX(glRasterPos2f)
#define glRasterPos3f TGL_ADD_PREFIX(glRasterPos3f)
#define glRasterPos4f TGL_ADD_PREFIX(glRasterPos4f)
#define glRasterPos2fv TGL_ADD_PREFIX(glRasterPos2fv)
#define glRasterPos3fv TGL_ADD_PREFIX(glRasterPos3fv)
#define glRasterPos4fv TGL_ADD_PREFIX(glRasterPos4fv)
#define glDrawPixels TGL_ADD_PREFIX(glDrawPixels)
#define glPixelZoom TGL_ADD_PREFIX(glPixelZoom)
#define glPostProcess TGL_ADD_PREFIX(glPostProcess)
#define glPolygonStipple TGL_ADD_PREFIX(glPolygonStipple)
#define glDebug TGL_ADD_PREFIX(glDebug)
#define glInit TGL_ADD_PREFIX(glInit)
#define glClose TGL_ADD_PREFIX(glClose)
#define glVertex2f TGL_ADD_PREFIX(glVertex2f)
#define glVertex2d TGL_ADD_PREFIX(glVertex2d)
#define glVertex2fv TGL_ADD_PREFIX(glVertex2fv)
#define glVertex2dv TGL_ADD_PREFIX(glVertex2dv)
#define glVertex3f TGL_ADD_PREFIX(glVertex3f)
#define glVertex3d TGL_ADD_PREFIX(glVertex3d)
#define glVertex3fv TGL_ADD_PREFIX(glVertex3fv)
#define glVertex3dv TGL_ADD_PREFIX(glVertex3dv)
#define glVertex4f TGL_ADD_PREFIX(glVertex4f)
#define glVertex4d TGL_ADD_PREFIX(glVertex4d)
#define glVertex4fv TGL_ADD_PREFIX(glVertex4fv)
#define glVertex4dv TGL_ADD_PREFIX(glVertex4dv)
#define glColor3f TGL_ADD_PREFIX(glColor3f)
#define glColor3d TGL_ADD_PREFIX(glColor3d)
#define glColor3fv TGL_ADD_PREFIX(glColor3fv)
#define glColor3dv TGL_ADD_PREFIX(glColor3dv)
#define glColor4f TGL_ADD_PREFIX(glColor4f)
#define glColor4d TGL_ADD_PREFIX(glColor4d)
#define glColor4fv TGL_ADD_PREFIX(glColor4fv)
#define glColor4dv TGL_ADD_PREFIX(glColor4dv)
#define glNormal3f TGL_ADD_PREFIX(glNormal3f)
#define glNormal3d TGL_ADD_PREFIX(glNormal3d)
#define glNormal3fv TGL_ADD_PREFIX(glNormal3fv)
#define glNormal3dv TGL_ADD_PREFIX(glNormal3dv)
#define glTexCoord1f TGL_ADD_PREFIX(glTexCoord1f)
#define glTexCoord1d TGL_ADD_PREFIX(glTexCoord1d)
#define glTexCoord1fv TGL_ADD_PREFIX(glTexCoord1fv)
#define glTexCoord1dv TGL_ADD_PREFIX(glTexCoord1dv)
#define glTexCoord2f TGL_ADD_PREFIX(glTexCoord2f)
#define glTexCoord2d TGL_ADD_PREFIX(glTexCoord2d)
#define glTexCoord2fv TGL_ADD_PREFIX(glTexCoord2fv)
#define glTexCoord2dv TGL_ADD_PREFIX(glTexCoord2dv)
#define glTexCoord3f TGL_ADD_PREFIX(glTexCoord3f)
#define glTexCoord3d TGL_ADD_PREFIX(glTexCoord3d)
#define glTexCoord3fv TGL_ADD_PREFIX(glTexCoord3fv)
#define glTexCoord3dv TGL_ADD_PREFIX(glTexCoord3dv)
#define glTexCoord4f TGL_ADD_PREFIX(glTexCoord4f)
#define glTexCoord4d TGL_ADD_PREFIX(glTexCoord4d)
#define glTexCoord4fv TGL_ADD_PREFIX(glTexCoord4fv)
#define glTexCoord4dv TGL_ADD_PREFIX(glTexCoord4dv)
#endif

/* functions */

void glEnable(GLint code);
void glDisable(GLint code);

void glShadeModel(GLint mode);
void glCullFace(GLint mode);
void glPolygonMode(GLint face, GLint mode);

void glBegin(GLint type);
void glEnd(void);
void glRectf(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2);
void glDrawBuffer(GLenum mode);
void glReadBuffer(GLenum mode);
void glReadPixels(GLint x,
                  GLint y,
                  GLsizei width,
                  GLsizei height,
                  GLenum format,
                  GLenum type,
                  void *data);
void glDrawArrays(GLenum mode, GLint first, GLsizei count);

void glSetEnableSpecular(GLint s);
void *glGetTexturePixmap(GLint text, GLint level, GLint *xsize, GLint *ysize);
void glDrawText(const GLubyte *text, GLint x, GLint y, GLuint pixel);
void glTextSize(GLTEXTSIZE mode);
void glPlotPixel(GLint x, GLint y, GLuint pixel);

void glVertex2f(GLfloat, GLfloat);
void glVertex2d(GLdouble, GLdouble);
void glVertex2fv(GLfloat *);
void glVertex2dv(GLdouble *);

void glVertex3f(GLfloat, GLfloat, GLfloat);
void glVertex3d(GLdouble, GLdouble, GLdouble);
void glVertex3fv(GLfloat *);
void glVertex3dv(GLdouble *);

void glVertex4f(GLfloat, GLfloat, GLfloat, GLfloat);
void glVertex4d(GLdouble, GLdouble, GLdouble, GLdouble);
void glVertex4fv(GLfloat *);
void glVertex4dv(GLdouble *);

void glColor3f(GLfloat, GLfloat, GLfloat);
void glColor3d(GLdouble, GLdouble, GLdouble);
void glColor3fv(GLfloat *);
void glColor3dv(GLdouble *);

void glColor4f(GLfloat, GLfloat, GLfloat, GLfloat);
void glColor4d(GLdouble, GLdouble, GLdouble, GLdouble);
void glColor4fv(GLfloat *);
void glColor4dv(GLdouble *);

void glNormal3f(GLfloat, GLfloat, GLfloat);
void glNormal3d(GLdouble, GLdouble, GLdouble);
void glNormal3fv(GLfloat *);
void glNormal3dv(GLdouble *);

void glTexCoord1f(GLfloat);
void glTexCoord1d(GLdouble);
void glTexCoord1fv(GLfloat *);
void glTexCoord1dv(GLdouble *);

void glTexCoord2f(GLfloat, GLfloat);
void glTexCoord2d(GLdouble, GLdouble);
void glTexCoord2fv(GLfloat *);
void glTexCoord2dv(GLdouble *);

void glTexCoord3f(GLfloat, GLfloat, GLfloat);
void glTexCoord3d(GLdouble, GLdouble, GLdouble);
void glTexCoord3fv(GLfloat *);
void glTexCoord3dv(GLdouble *);

void glTexCoord4f(GLfloat, GLfloat, GLfloat, GLfloat);
void glTexCoord4d(GLdouble, GLdouble, GLdouble, GLdouble);
void glTexCoord4fv(GLfloat *);
void glTexCoord4dv(GLdouble *);


void glEdgeFlag(GLint flag);

/* matrix */
void glMatrixMode(GLint mode);
void glLoadMatrixf(const GLfloat *m);
void glLoadIdentity(void);
void glMultMatrixf(const GLfloat *m);
void glPushMatrix(void);
void glPopMatrix(void);
void glRotatef(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
void glTranslatef(GLfloat x, GLfloat y, GLfloat z);
void glScalef(GLfloat x, GLfloat y, GLfloat z);

void glViewport(GLint x, GLint y, GLint width, GLint height);
void glFrustum(GLdouble left,
               GLdouble right,
               GLdouble bottom,
               GLdouble top,
               GLdouble near,
               GLdouble far);

/* lists */
GLuint glGenLists(GLint range);
GLint glIsList(GLuint list);
void glNewList(GLuint list, GLint mode);
void glEndList(void);
void glCallList(GLuint list);
void glCallLists(GLsizei n, GLenum type, const GLuint *lists);
void glListBase(GLint n);
void glDeleteList(GLuint list);
void glDeleteLists(GLuint list, GLuint range);

/* clear */
void glClear(GLint mask);
void glClearColor(GLfloat r, GLfloat g, GLfloat b, GLfloat a);
void glClearDepth(GLdouble depth);

/* Feedback */
void glFeedbackBuffer(GLint size, GLenum type, GLfloat *buf);
void glPassThrough(GLfloat token);

/* selection */
GLint glRenderMode(GLint mode);
void glSelectBuffer(GLint size, GLuint *buf);

void glInitNames(void);
void glPushName(GLuint name);
void glPopName(void);
void glLoadName(GLuint name);

/* textures */
void glGenTextures(GLint n, GLuint *textures);
void glDeleteTextures(GLint n, const GLuint *textures);
void glBindTexture(GLint target, GLint texture);
void glTexImage2D(GLint target,
                  GLint level,
                  GLint components,
                  GLint width,
                  GLint height,
                  GLint border,
                  GLint format,
                  GLint type,
                  void *pixels);

void glTexImage1D(GLint target,
                  GLint level,
                  GLint components,
                  GLint width,
                  GLint border,
                  GLint format,
                  GLint type,
                  void *pixels);
void glCopyTexImage2D(GLenum target,
                      GLint level,
                      GLenum internalformat,
                      GLint x,
                      GLint y,
                      GLsizei width,
                      GLsizei height,
                      GLint border);
void glTexEnvi(GLint target, GLint pname, GLint param);

void glTexParameteri(GLint target, GLint pname, GLint param);

GLboolean glAreTexturesResident(GLsizei n,
                                const GLuint *textures,
                                GLboolean *residences);
GLboolean glIsTexture(GLuint texture);

/* lighting */
void glMaterialfv(GLint mode, GLint type, GLfloat *v);
void glMaterialf(GLint mode, GLint type, GLfloat v);
void glColorMaterial(GLint mode, GLint type);

void glLightfv(GLint light, GLint type, GLfloat *v);
void glLightf(GLint light, GLint type, GLfloat v);
void glLightModeli(GLint pname, GLint param);
void glLightModelfv(GLint pname, GLfloat *param);

/* misc */

void glFlush(void);
void glFinish(void);
void glHint(GLint target, GLint mode);
void glGetIntegerv(GLint pname, GLint *params);
void glGetFloatv(GLint pname, GLfloat *v);
const GLubyte *glGetString(GLenum name);
GLenum glGetError();
void glFrontFace(GLint mode);

/* OpenGL 1.2 arrays */
void glEnableClientState(GLenum array);
void glDisableClientState(GLenum array);
void glArrayElement(GLint i);
void glVertexPointer(GLint size,
                     GLenum type,
                     GLsizei stride,
                     const GLvoid *pointer);
void glColorPointer(GLint size,
                    GLenum type,
                    GLsizei stride,
                    const GLvoid *pointer);
void glNormalPointer(GLenum type, GLsizei stride, const GLvoid *pointer);
void glTexCoordPointer(GLint size,
                       GLenum type,
                       GLsizei stride,
                       const GLvoid *pointer);

/* OpenGL 2.0 buffers */
void glGenBuffers(GLsizei n, GLuint *buffers);
void glDeleteBuffers(GLsizei n, const GLuint *buffers);
void glBindBuffer(GLenum target, GLuint buffer);
GLboolean glIsBuffer(GLuint buffer);
void *glMapBuffer(GLenum target, GLenum access);
void glBufferData(GLenum target, GLsizei size, const void *data, GLenum usage);

void glBindBufferAsArray(GLenum target,
                         GLuint buffer,
                         GLenum type,
                         GLint size,
                         GLint stride);

/* OpenGL 1.2 polygon offset */
void glPolygonOffset(GLfloat factor, GLfloat units);
void glBlendFunc(GLint, GLint);
void glBlendEquation(GLenum mode);
void glDepthMask(GLint);

/* Point Size */
void glPointSize(GLfloat);

/* Raster rendering */
void glRasterPos2f(GLfloat, GLfloat);
void glRasterPos3f(GLfloat, GLfloat, GLfloat);
void glRasterPos4f(GLfloat, GLfloat, GLfloat, GLfloat);

void glRasterPos2fv(GLfloat *v);
void glRasterPos3fv(GLfloat *v);
void glRasterPos4fv(GLfloat *v);
void glDrawPixels(GLsizei width,
                  GLsizei height,
                  GLenum format,
                  GLenum type,
                  void *data);
void glPixelZoom(GLfloat x, GLfloat y);

/* PostProcessing pass implementation */
void glPostProcess(
    GLuint (*postprocess)(GLint x, GLint y, GLuint pixel, GLushort z));

/* not implemented, just added to compile  */
#if 0
inline void glLineWidth(GLfloat) {}
inline void glDepthFunc(GLint) {}

inline void glTexEnvf(GLint, GLint, GLint) {}
inline void glOrtho(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat){}
inline void glVertex2i(GLint,GLint) {}
inline void glDepthMask(GLint) {}
inline void glFogi(GLint, GLint) {}
inline void glFogfv(GLint, const GLfloat*) {}
inline void glFogf(GLint, GLfloat) {}
inline void glTexParameterf(GLint, GLint, GLint) {};
#endif

void glPolygonStipple(void *a);
/* non compatible functions */

void glDebug(GLint mode);

void glInit(void *zbuffer);
void glClose(void);

#ifdef __cplusplus
}
#endif

#endif
