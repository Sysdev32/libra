#ifndef _ENDIAN_H
#define _ENDIAN_H

#include <stdint.h>
#include <byteswap.h>

/* Endian constants */
#define LITTLE_ENDIAN 1234
#define BIG_ENDIAN    4321
#define PDP_ENDIAN    3412

/* Native byte order */
#define BYTE_ORDER LITTLE_ENDIAN

/* Host ↔ little endian */
#define htole16(x) ((uint16_t)(x))
#define htole32(x) ((uint32_t)(x))
#define htole64(x) ((uint64_t)(x))

#define le16toh(x) ((uint16_t)(x))
#define le32toh(x) ((uint32_t)(x))
#define le64toh(x) ((uint64_t)(x))

/* Host ↔ big endian */
#define htobe16(x) bswap_16((uint16_t)(x))
#define htobe32(x) bswap_32((uint32_t)(x))
#define htobe64(x) bswap_64((uint64_t)(x))

#define be16toh(x) bswap_16((uint16_t)(x))
#define be32toh(x) bswap_32((uint32_t)(x))
#define be64toh(x) bswap_64((uint64_t)(x))

#endif /* _ENDIAN_H */