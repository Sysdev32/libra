#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#include <carrera.h>
#include <stdbool.h>
#define CHUNK_SIZE 512
#define BG_WIDTH  1920
#define BG_HEIGHT 1080
#define MOUSE_CURSOR_SIZE 10
#define MOUSE_SENSITIVITY 4
#define MAX_MOUSE_DELTA 40
#define MOUSE_LEFT_BUTTON_BIT 0x01
#define MOUSE_RIGHT_BUTTON_BIT  0x02  // 00000010
#define MOUSE_MIDDLE_BUTTON_BIT 0x04  // 00000100
/* EMA Mouse Smoothing Constants */
#define MOUSE_EMA_NEW_WEIGHT 3
#define MOUSE_EMA_TOTAL      4

/* Geometry Layout Constants */
#define TITLE_BAR_HEIGHT     24
#define WINDOW_BORDER_THICK  4
#define DEFAULT_FONT_HEIGHT  16.0f
#define PRINTF_BUFFER_SIZE   1024
#define WINDOW_CORNER_RADIUS 8
#define BTN_RADIUS           6
#define BTN_SPACING          18

#define ANIMATION_LERP_FACTOR 0.25f
struct pixel {
    uint8_t r; uint8_t g; uint8_t b; uint8_t a;
};

enum EventType {
    EVENT_MOUSE_CLICK, EVENT_MOUSE_MOVE, EVENT_KEYBOARD_PRESS, EVENT_KEYBOARD_RELEASE, EVENT_BUTTON_PRESS, EVENT_BUTTON_RELEASE
};

struct event {
    enum EventType type;
    union {
        struct { int x; int y; } mouse_move;
        struct { int button; int x; int y; } mouse_click;
        struct { char key; } keyboard;
        struct { int id; } button;
    };
};
typedef enum {
    WIDGET_BUTTON,
    WIDGET_TEXT,
} WidgetType;
typedef struct {
    WidgetType type;
    union {
        struct {
            char text[32];
            int width;
            int height;
            int font;
            int x;
            int y;
            float fontsize;
            int id;
        } button;
        struct {
            char text[32];
            int font;
            int x;
            int y;
            float fontsize;
            int id;
        } text;
    };
} widget;
typedef struct {
    struct event ev[32];
    int evlen;
} wevents;
struct window {
    float x;      
    float y;
    int prev_x; 
    int prev_y;
    int height; 
    int width;  
    bool draggable;
    bool is_dirty; 
    struct pixel **pixels;
    void (*update)(void);
    void (*event_handler)(struct wevents ev);
    uint32_t id;
    char title[256];
};

/* Damage Tracking Geometry Structural Primitive */
struct rect_region {
    int x, y, w, h;
};
int RavenPrintChar(int x, int y, float h, char print);
int RavenCreateWindow(int x, int y, int width, int height, const char *title, void (*update)(void), void (*event_handler)(wevents ev));
void RavenDestroyWindow(uint32_t id);
void RavenSwitchFont(const char *font_path);
int RavenDrawPixel(int x, int y, struct pixel rgb);
struct rect_region* RavenInternalGetClip();
struct window* RavenInternalGetWindowList();
uint32_t RavenInternalGetWindowID();
int RavenChangeTitle(char* title);
int RavenChangeWidth(uint32_t width);
int RavenChangeHeight(uint32_t height);
int RavenChangeX(uint32_t x);
int RavenChangeY(uint32_t y);
int RavenDrawRect(int x, int y, int width, int height, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawCircle(int cx, int cy, int radius, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawRoundedRect(int x, int y, int width, int height, int radius, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawTriangle(int x0, int y0, int x1, int y1, int x2, int y2, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawParellelogram(int x, int y, int width, int height, int skew, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawTrapezoid(int x, int y, int top_width, int bottom_width, int height, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawDiamond(int cx, int cy, int half_width, int half_height, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
int RavenDrawRhombus(int cx, int cy, int half_width, int half_height, bool fill, struct pixel fill_rgb, struct pixel outline_rgb);
struct pixel* RGB(int r, int g, int b);

typedef struct { int16_t dx; int16_t dy; uint16_t width; uint16_t height; } cursor_delta_t;
extern int g_mouse_dx_state;
extern int g_mouse_dy_state;
extern int g_mouse_dx_error;
extern int g_mouse_dy_error;
typedef struct {
    int x;
    int y;
    int buttons;
} mouse;
mouse RavenGetMouse();