// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#include <sys/types.h>
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int socklen_t;
typedef unsigned short sa_family_t;
#define SOCK_STREAM    1
#define SOCK_DGRAM     2
#define SOCK_RAW       3
#define SOCK_RDM       4
#define SOCK_SEQPACKET 5
#define B0 0
#define B50 1
#define B75 2
#define B110 3
#define B134 4
#define B150 5
#define B200 6
#define B300 7
#define B600 8
#define B1200 9
#define B1800 10
#define B2400 11
#define B4800 12
#define B9600 13
#define B19200 14
#define B38400 15
#define B57600 16
#define B115200 17
#define B230400 18
struct sockaddr {
    sa_family_t sa_family;
    char sa_data[14];
};

struct sockaddr_storage {
    sa_family_t ss_family;
    char __data[126];
};

#define AF_UNSPEC 0
#define AF_UNIX   1
#define AF_INET   2
#define AF_INET6  10

#define SOCK_STREAM 1
#define SOCK_DGRAM  2
#define SOCK_RAW    3

#define SOL_SOCKET 1
typedef enum {
    NET_AF_IPV4,
    NET_AF_IPV6,
    NET_AF_ARP,
    NET_AF_RAW
} net_family_t;

typedef enum {
    NET_PROTO_TCP,
    NET_PROTO_UDP,
    NET_PROTO_ICMP,
    NET_PROTO_RAW
} net_protocol_t;
typedef struct net_socket net_socket;
typedef struct {
    uint64_t connect_udp_port;
    uint64_t connect_tcp_port;
    uint64_t my_udp_port;
    uint64_t my_tcp_port;
    uint32_t dest_ip;
    int index;
    uint8_t connected;
    char path[256];
} metadata;
typedef struct net_addr {
    uint32_t ipv4;      // Network byte order
    uint16_t port;      // Network byte order
} net_addr;
typedef int (*net_recv_t)(
    struct net_socket *socket,
    void *buffer,
    size_t length
);

typedef int (*net_send_t)(
    struct net_socket *socket,
    const void *buffer,
    size_t length
);

typedef int (*net_connect_t)(
    struct net_socket *socket,
    const char *addr
);

typedef int (*net_close_t)(
    struct net_socket *socket
);
struct net_socket {
    net_family_t family;
    net_protocol_t protocol;
    net_recv_t recv;
    net_close_t close;
    net_connect_t connect;
    net_send_t send;
    metadata md;
};
int socket(net_family_t family, net_protocol_t protocol);
int connect(int sockfd, const char* address);

ssize_t send(int sockfd, const void *buf, size_t len);
ssize_t recv(int sockfd, void *buf, size_t len);

#ifdef __cplusplus
}
#endif