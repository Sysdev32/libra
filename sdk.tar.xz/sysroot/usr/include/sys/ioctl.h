// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>

int ioctl(int fd, unsigned long request, ...);

#ifdef __cplusplus
}
#endif