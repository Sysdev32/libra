#pragma once

#define major(dev) (((dev) >> 8) & 0xff)
#define minor(dev) ((dev) & 0xff)
#define makedev(ma, mi) (((ma) << 8) | (mi))