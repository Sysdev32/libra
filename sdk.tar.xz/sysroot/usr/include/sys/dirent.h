
#include <stdint.h>
struct dirent {
    uint32_t d_ino;       // Unique inode number of the file/folder
    uint32_t d_type;      // Type marker: 4 for Directory (DT_DIR), 8 for Regular File (DT_REG)
    char d_name[256];     // Null-terminated filename string
};

/**
 * Opaque userspace handle structure representing an active directory stream.
 * This tracks the state required to read sequential entries from a directory file descriptor.
 */
typedef struct {
    int fd;                 // The underlying userspace file descriptor assigned to the directory
    uint64_t offset;        // Current child element read cursor tracking index
    struct dirent entry;    // Local storage cache used to return stable structure references
} DIR;