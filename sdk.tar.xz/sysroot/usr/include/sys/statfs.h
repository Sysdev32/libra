// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#include <stdint.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef uint64_t fsblkcnt_t;

typedef struct {
    int __val[2];
} fsid_t;

struct statfs {
    uint64_t    f_type;
    uint64_t    f_bsize;

    fsblkcnt_t  f_blocks;
    fsblkcnt_t  f_bfree;
    fsblkcnt_t  f_bavail;

    fsfilcnt_t  f_files;
    fsfilcnt_t  f_ffree;

    fsid_t      f_fsid;

    uint64_t    f_namelen;
    uint64_t    f_frsize;
    uint64_t    f_flags;

    uint64_t    f_spare[4];
};

int statfs(const char *path, struct statfs *buf);
int fstatfs(int fd, struct statfs *buf);

#ifdef __cplusplus
}
#endif