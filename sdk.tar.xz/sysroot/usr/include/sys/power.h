#pragma once
void reboot();
void poweroff();