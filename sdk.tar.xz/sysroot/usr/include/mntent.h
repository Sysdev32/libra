// SPDX-License-Identifier: GPL-3.0-only
#pragma once

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

struct mntent {
    char *mnt_fsname;   /* filesystem name */
    char *mnt_dir;      /* mount point */
    char *mnt_type;     /* filesystem type */
    char *mnt_opts;     /* mount options */
    int   mnt_freq;     /* dump frequency */
    int   mnt_passno;   /* fsck pass number */
};

FILE *setmntent(const char *filename, const char *type);
struct mntent *getmntent(FILE *stream);
int endmntent(FILE *stream);
char *hasmntopt(const struct mntent *mnt, const char *opt);

#ifdef __cplusplus
}
#endif